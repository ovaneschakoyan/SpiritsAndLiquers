﻿using SpiritsAndLiquers.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpiritsAndLiquers.Data.interfaces
{
    public interface ISpiritsAndWineRepository
    {
        IEnumerable<SpiritsAndWine> SpiritsAndWines { get; }
        IEnumerable<SpiritsAndWine> PreferredDrinks { get; }
        SpiritsAndWine GetDrinkById(int drinkId);
    }
}
