﻿using Microsoft.AspNetCore.Builder;
using SpiritsAndLiquers.Data.Models;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Generic;
using System.Linq;

namespace SpiritsAndLiquers.Data
{
    public class DbInitializer
    {
        public static void Seed(IApplicationBuilder applicationBuilder)
        {
            AppDbContext context =
                applicationBuilder.ApplicationServices.GetRequiredService<AppDbContext>();

            if(!context.Categories.Any())
            {
                context.Categories.AddRange(Categories.Select(c => c.Value));
            }

            if(!context.SpiritAndWines.Any())
            {
                context.AddRange
                    (
                    new SpiritsAndWine
                    {
                        Name = "Radius Merlot",
                        Price = 9.89M, ShortDescription = "Fresh . Vanilla . Raspberry	. Medium-bodied",
                        LongDescription = "Winemakers love Merlot grapes because they are easy to grow and quick to ripen. Casual wine drinkers appreciate that Merlot wines can be soft and approachable, with delicious dark fruit flavors. In Merlot blends, the grapes add a moderating influence, providing measured tannins, soft texture, medium acidity and medium alcohol. Accordingly, Merlot balances the more rustic and herbaceous qualities of Cabernet Sauvignon, a frequent blending partner.Merlot can also make complex,full - bodied and concentrated wines with grippy tannins and aging potential.Many connoisseurs consider the best Merlot wine to come from Bordeaux’s Right Bank,where the varietal predominates in wines from St.-Émilion,Pomerol and other renowned appellations.Merlot is also blended to excellent effect with the other red Bordeaux varieties,Cabernet Franc and Petit Verdot.",
                        Category = Categories["Red Wines"],
                        ImageUrl = "https://image.ibb.co/jroHbv/radiusmerlot_l.png",
                        InStock = true,
                        IsPreferred = true,
                        ImageThumbnailUrl = "https://image.ibb.co/hCjJia/radiusmerlot.png"
                    },
                       new SpiritsAndWine
                       {
                           Name = "Radius Merlot",
                           Price = 11.49M,
                           ShortDescription = "Light,fresh taste with prominent yet delicate flavors of ripe raspberry and cherry.",
                           LongDescription = "Best described as an elegant wine with a strong sense of identity.  There are some wonderful essences of blueberry, strawberry, raspberry, cranberry and cherry.  With these bright fruits are some darker aged fruits such as date and figs.  Along with this there is a soft forest floor note that brings in a great earthy character to the wine which is balanced well with some notes of vanilla and violet’s lending a floral quality.  The tannins are string yet still smooth and approachable. The oak is wonderfully incorporated into the wine.  All of these aspects lend themselves to creating an elegant wine",
                           Category = Categories["Red Wines"],
                           ImageUrl = "https://image.ibb.co/gkFxbv/petermerlot_l.png",
                           InStock = true,
                           IsPreferred = true,
                           ImageThumbnailUrl = "https://image.ibb.co/dOM3Gv/petermerlot.png"
                       },
                       new SpiritsAndWine
                       {
                           Name = "2015 Gabriel Archer Reservet",
                           Price = 42.00M,
                           ShortDescription = "36% Cabernet Franc, 25% Merlot, 20% Cabernet Sauvignon, 12% Petit Verdot and 7% Malbec",
                           LongDescription = "The 2015 has all the elements of a great old world wine.  There is an abundance of berries, black cherry, cassis and a touch of some dark fruits.  The fruit is well paired with a nice earthy forest floor, truffle/mushroom note along with some suede.  All of this has been sprinkled with some fresh cocoa powder.  Additionally there is a hint of eucalyptus and herbal nuances.  The tannins are very well matched with the oak and offers a long expressive finish to the wine.  Overall this is a very well balanced wine and probably one of my favorite Gabriel Archers.",
                           Category = Categories["Red Wines"],
                           ImageUrl = "https://image.ibb.co/gJLDGv/2015_Gabriel_Archer_Reserve.jpg",
                           InStock = true,
                           IsPreferred = true,
                           ImageThumbnailUrl = "https://image.ibb.co/jFBLwv/2015_Gabriel_Archer_Reserve_tn.jpg"
                       },
                       new SpiritsAndWine
                       {
                           Name = "2015 Barrel Aged Claret",
                           Price = 19.00M,
                           ShortDescription = "65% cabernet franc, 23% merlot, 6% cabernet sauvignon, 6% Norton",
                           LongDescription = "he Claret a lot of varying levels of bright red fruit such as cherry, raspberry and strawberry followed by hint of cran-apple.  The fruit is accompanied by some earthy tones of leather/suede, olives and a herbaceous potpourri nuance that blends well the cocoa/ and vanilla notes.  The palette has a bright lingering touch of red fruit and earthy characters that mingle well with the mild/soft oak and tannins.  This is a lovely wine for food.",
                           Category = Categories["Red Wines"],
                           ImageUrl = "https://i.imgur.com/9KTteM0.png",
                           InStock = true,
                           IsPreferred = true,
                           ImageThumbnailUrl = "https://i.imgur.com/NnzARuB.jpg"
                       },
                       new SpiritsAndWine
                       {
                           Name = "2015 Vintage Reserve Chardonnay",
                           Price = 32.00M,
                           ShortDescription = "100% Chardonnay",
                           LongDescription = "It has been awhile since the last VRC and I am happy to report the wait was worth it.  The 2015 is showing some wonderful upfront tropical characters of pineapple, orange and banana with some apricot and plum to round out the fruits.  There is a very clean creamy lemon note with some vanilla.  The mineraily of the wine is nicely balanced with the fruits.  The oak is not overstated and blends nicely with the fruit and minerality of the wine.  The finish is luscious with many layers and complexities.  An elevated classic chardonnay that will pair well with a lobster or ribeye steak.",
                           Category = Categories["White Wines"],
                           ImageUrl = "https://i.imgur.com/GZcF7BE.jpg",
                           InStock = true,
                           IsPreferred = true,
                           ImageThumbnailUrl = "https://i.imgur.com/CYYpSoO.jpg"
                       },
                       new SpiritsAndWine
                       {
                           Name = "2015 A Midsummer Night's White",
                           Price = 14.00M,
                           ShortDescription = "59% Traminette, 32% Vidal Blanc, 9% Viognier",
                           LongDescription = "A lovely floral, tropical bouquet offering many layers of orange, tangerine, banana, pineapple and a bit of lemongrass.  There is a very soft honeysuckle and vanilla that offers an additional richness to the wine, along with a touch of minerality and spice.  The finish is rich and creamy with an elegant mouth feel that blends well with the brightness of the wine.  “Sunshine in a bottle”, according to one of our Board Members…and we agree!",
                           Category = Categories["White Wines"],
                           ImageUrl = "https://i.imgur.com/pSBuP1H.png",
                           InStock = true,
                           IsPreferred = true,
                           ImageThumbnailUrl = "https://i.imgur.com/FamKi2r.jpg"
                       },
                       new SpiritsAndWine
                       {
                           Name = "2014 John Adlum Chardonnay",
                           Price = 14.00M,
                           ShortDescription = "The grapes were harvested early in 2014 and the wine was fermented in stainless steel for approximately one week under cool temperatures using a French Yeast.  The wine was aged in stainless steel to retain the fruit and brightness.",
                           LongDescription = "A bright approachable chardonnay offering many classic characters of lemon, apple, pear, and a touch of tropical pineapple.  There is a nice creaminess to the wine that is expressed in the mouth feel.  The fresh hay/straw characters blends well with the fruit and vanilla tones.  The finish is bright and fruit forward with a touch of the tropical lingering a bit longer.  Overall a chardonnay for everyone!",
                           Category = Categories["White Wines"],
                           ImageUrl = "https://i.imgur.com/QB5hrvU.png",
                           InStock = true,
                           IsPreferred = true,
                           ImageThumbnailUrl = "https://i.imgur.com/zD2KCea.jpg"
                       },
                       new SpiritsAndWine
                       {
                           Name = "Vin Licoreux de Framboise(Wine with Raspberry)",
                           Price = 19.00M,
                           ShortDescription = "A blend of barrel aged and stainless steel Red Wine and Raspberry",
                           LongDescription = "This Raspberry Wine is a blend of raspberry and red wine.  The red grape wine is comprised predominately of Merlot.  Ultimately the raspberry character is the most forward with the red grape wine following on the back palette.  The combination of both flavor profiles offers a nice balance of the different fruits and their particular nuances they each share.This is a very pleasant dessert wine which will go with many desserts but I would strongly recommend a rich cheesecake with fresh berries or anything with the word chocolate in it. ",
                           Category = Categories["Dessert Wines"],
                           ImageUrl = "https://i.imgur.com/DDaCtVc.jpg",
                           InStock = true,
                           IsPreferred = true,
                           ImageThumbnailUrl = "https://i.imgur.com/YR5Ax3V.jpg"
                       },
                       new SpiritsAndWine
                       {
                           Name = "2016 Petite Fleur ",
                           Price = 24.00M,
                           ShortDescription = "79% Vidal Blanc, 21% Muscat Canelli",
                           LongDescription = "The 2016 Rosé Petite Fleur is a dry Sideritis coming in at 12.5% alcohol. Light and elegant, this is just bursting with flavor on the finish. It starts with a pale salmon color, but there is nothing pale about fruity finish. The flavors are controlled, though, and it finishes dry and crisp. This elegant pink is more like a white than a red in style and it seems to be a better wine than the actual Sideritis white, showing all the charm, personality and focus that wine does not (yet) have. (I still think it will get there.) If the white this issue is all about the potential a few months down the road, this is all about the here and now. Drink it this summer. Revel in its lifted flavors, airy demeanor and very graceful construction.",
                           Category = Categories["Dessert Wines"],
                           ImageUrl = "https://i.imgur.com/4AfeCYv.jpg",
                           InStock = true,
                           IsPreferred = true,
                           ImageThumbnailUrl = "https://i.imgur.com/chZHrrs.jpg"
                       },
                       new SpiritsAndWine
                       {
                           Name = "Tito's Handmade Vodka ",
                           Price = 15.99M,
                           ShortDescription = " Crisp . Clean	. Smooth	",
                           LongDescription = "Designed to be savored by spirit connoisseurs. Micro-distilled in an old-fashioned pot still to provide more control over the distillation process and resulting in a spectacularly clean product. Only the heart of the run is taken, leaving behind residual higher and lower alcohols.",
                           Category = Categories["Vodka"],
                           ImageUrl = "https://i.imgur.com/BK7NfHI.png",
                           InStock = true,
                           IsPreferred = true,
                           ImageThumbnailUrl = "https://i.imgur.com/sNDOhnv.jpg"
                       },
                       new SpiritsAndWine
                       {
                           Name = "Grey Goose ",
                           Price = 36.99M,
                           ShortDescription = "  Creamy	. Smooth		",
                           LongDescription = "France- Created in the celebrated Cognac region, from the finest French wheat and natural spring water filtered through champagne limestone. Distilled in copper 5 times in small batches. Nice chilled and straight or high quality cocktails.",
                           Category = Categories["Vodka"],
                           ImageUrl = "https://i.imgur.com/UVwSMb8.png",
                           InStock = true,
                           IsPreferred = true,
                           ImageThumbnailUrl = "https://i.imgur.com/ltrHPzN.jpg"
                       },
                        new SpiritsAndWine
                        {
                            Name = "Platinum Vodka 7X Traveler ",
                            Price = 13.49M,
                            ShortDescription = "7 times distilled.The resulting product is a remarkable in its clean,refreshing, smooth taste.",
                            LongDescription = "The Buffalo Trace Distillery is best known for making bourbons but has also recently gotten involved in vodka production.Platinum 7x vodka is named for its multiple (seven) distillations.The first four are done in column stills with three more in more traditional special pot stills. It is made with American corn(a necessary component for bourbon production) and then blended with limestone water. ",
                            Category = Categories["Vodka"],
                            ImageUrl = "https://i.imgur.com/Til9pSg.png",
                            InStock = true,
                            IsPreferred = true,
                            ImageThumbnailUrl = "https://i.imgur.com/Wlv22FI.jpg"
                        },
                        new SpiritsAndWine
                        {
                            Name = "Redemption Rye",
                            Price = 32.49M,
                            ShortDescription = " Light . Rye . Floral . Citrus	. Balanced	",
                            LongDescription = "Beautiful flavored Rye Spice with light floral and citrus notes. Slight mint finish makes this great for sipping or mixing in a classic cocktail. True Rye flavor due to the 95% Rye in the mash bill. ",
                            Category = Categories["Rye Whiskey"],
                            ImageUrl = "https://i.imgur.com/dDPHjLn.png",
                            InStock = true,
                            IsPreferred = true,
                            ImageThumbnailUrl = "https://i.imgur.com/TsaivGK.jpg"
                        },
                        new SpiritsAndWine
                        {
                            Name = "Woodford Reserve Rye",
                            Price = 31.99M,
                            ShortDescription = " Ultimate Spirits Challenge",
                            LongDescription = "Kentucky- Made in the traditional style of Kentucky Ryes delivering bold flavors of pepper and tobacco with a long fruit and sweetly spiced finish. Gold Medal San Francisco World Spirits 2016. Gold Medal Whiskies of the World 2016.",
                            Category = Categories["Rye Whiskey"],
                            ImageUrl = "https://i.imgur.com/4RMMnMt.png",
                            InStock = true,
                            IsPreferred = true,
                            ImageThumbnailUrl = "https://i.imgur.com/Vizf5Kt.jpg"
                        },
                        new SpiritsAndWine
                        {
                            Name = "Clyde May's Straight Bourbon 92 PF",
                            Price = 39.99M,
                            ShortDescription = "  Light . Spice . Fruit	. Long	",
                            LongDescription = "Kentucky - This 5yr old non - chill filtered Straight Bourbon is an instant classic.Soft nose with hints of strawberry,baked apricot and nutmeg with a full mouth feel that finishes long and delicious. 2016 Ultimate Spirits Challenge Gold Medal Award Winner.",
                            Category = Categories["Bourbon"],
                            ImageUrl = "https://i.imgur.com/jc6oUSm.png",
                            InStock = true,
                            IsPreferred = true,
                            ImageThumbnailUrl = "https://i.imgur.com/uy2XNcT.jpg"
                        },
                         new SpiritsAndWine
                         {
                             Name = "Jefferson's Very Small Batch Bourbon",
                             Price = 26.99M,
                             ShortDescription = "  Light . Spice . Fruit	. Long	",
                             LongDescription = "Wine Enthusiast -Kentucky, USA-...The vibrant entry gives off oaky sweet tastes of vanilla,baked bread and buttered popcorn; at midpalate rich flavors of molasses, burnt sugar, oak resin, maple and honey vie for dominance.Finished properly spirited, semisweet and assertive.",
                             Category = Categories["Bourbon"],
                             ImageUrl = "https://i.imgur.com/xZjce2v.png",
                             InStock = true,
                             IsPreferred = true,
                             ImageThumbnailUrl = "https://i.imgur.com/ip0UjQw.jpg"
                         }
                       );
             
            }

            context.SaveChanges();
        }

        private static Dictionary<string, Category> categories;
        public static Dictionary<string,Category> Categories
        {
            get
            {
                if(categories==null)
                {
                    var genresList = new Category[]
                    {
                        new Category{CategoryName="Red Wines",Description="All types red wines"},
                        new Category{CategoryName="White Wines",Description="All types white wines"},
                        new Category{CategoryName="Dessert Wines",Description="All types dessert wines"},
                        new Category{CategoryName="Vodka",Description="All types vodka"},
                        new Category{CategoryName="Rye Whiskey",Description="All types rye whiskey"},
                        new Category{CategoryName="Bourbon",Description="All types bourbons"}

                    };

                    categories = new Dictionary<string, Category>();

                    foreach(Category genre in genresList)
                    {
                        categories.Add(genre.CategoryName, genre);
                    }
                }

                return categories;
            }
        }
    }
}
