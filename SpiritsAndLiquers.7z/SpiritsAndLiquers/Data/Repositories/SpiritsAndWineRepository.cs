﻿using SpiritsAndLiquers.Data.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SpiritsAndLiquers.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace SpiritsAndLiquers.Data.Repositories
{
    public class SpiritsAndWineRepository : ISpiritsAndWineRepository
    {
        private readonly AppDbContext _appDbContext;

        public SpiritsAndWineRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public IEnumerable<SpiritsAndWine> SpiritsAndWines => _appDbContext.SpiritAndWines.Include(c => c.Category);


        public IEnumerable<SpiritsAndWine> PreferredDrinks => _appDbContext.SpiritAndWines.Where(p => p.IsPreferred).Include(c => c.Category);


        public SpiritsAndWine GetDrinkById(int drinkId) => _appDbContext.SpiritAndWines.FirstOrDefault(p => p.SpiritsAndWineId == drinkId);
       
    }
}
