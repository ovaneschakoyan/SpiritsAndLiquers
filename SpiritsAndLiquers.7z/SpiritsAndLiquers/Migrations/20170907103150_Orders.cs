﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Metadata;

namespace SpiritsAndLiquers.Migrations
{
    public partial class Orders : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ShoppingCartItems_SpiritAndWines_GetSpiritsAndWineSpiritsAndWineId",
                table: "ShoppingCartItems");

            migrationBuilder.RenameColumn(
                name: "GetSpiritsAndWineSpiritsAndWineId",
                table: "ShoppingCartItems",
                newName: "SpiritsAndWineId");

            migrationBuilder.RenameIndex(
                name: "IX_ShoppingCartItems_GetSpiritsAndWineSpiritsAndWineId",
                table: "ShoppingCartItems",
                newName: "IX_ShoppingCartItems_SpiritsAndWineId");

            migrationBuilder.CreateTable(
                name: "Orders",
                columns: table => new
                {
                    OrderId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AdressLine1 = table.Column<string>(nullable: true),
                    AdressLine2 = table.Column<string>(nullable: true),
                    AdressLine3 = table.Column<string>(nullable: true),
                    Country = table.Column<string>(nullable: true),
                    Email = table.Column<string>(nullable: true),
                    FirstName = table.Column<string>(nullable: true),
                    LastName = table.Column<string>(nullable: true),
                    OrderPlaced = table.Column<DateTime>(nullable: false),
                    OrderTotal = table.Column<decimal>(nullable: false),
                    PhoneNumber = table.Column<string>(nullable: true),
                    State = table.Column<string>(nullable: true),
                    ZipCode = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Orders", x => x.OrderId);
                });

            migrationBuilder.CreateTable(
                name: "OrderDetails",
                columns: table => new
                {
                    OrderDetailId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Amount = table.Column<int>(nullable: false),
                    OrderId = table.Column<int>(nullable: false),
                    Price = table.Column<decimal>(nullable: false),
                    ProductId = table.Column<int>(nullable: false),
                    SpiritsAndWineId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrderDetails", x => x.OrderDetailId);
                    table.ForeignKey(
                        name: "FK_OrderDetails_Orders_OrderId",
                        column: x => x.OrderId,
                        principalTable: "Orders",
                        principalColumn: "OrderId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_OrderDetails_SpiritAndWines_SpiritsAndWineId",
                        column: x => x.SpiritsAndWineId,
                        principalTable: "SpiritAndWines",
                        principalColumn: "SpiritsAndWineId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_OrderDetails_OrderId",
                table: "OrderDetails",
                column: "OrderId");

            migrationBuilder.CreateIndex(
                name: "IX_OrderDetails_SpiritsAndWineId",
                table: "OrderDetails",
                column: "SpiritsAndWineId");

            migrationBuilder.AddForeignKey(
                name: "FK_ShoppingCartItems_SpiritAndWines_SpiritsAndWineId",
                table: "ShoppingCartItems",
                column: "SpiritsAndWineId",
                principalTable: "SpiritAndWines",
                principalColumn: "SpiritsAndWineId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ShoppingCartItems_SpiritAndWines_SpiritsAndWineId",
                table: "ShoppingCartItems");

            migrationBuilder.DropTable(
                name: "OrderDetails");

            migrationBuilder.DropTable(
                name: "Orders");

            migrationBuilder.RenameColumn(
                name: "SpiritsAndWineId",
                table: "ShoppingCartItems",
                newName: "GetSpiritsAndWineSpiritsAndWineId");

            migrationBuilder.RenameIndex(
                name: "IX_ShoppingCartItems_SpiritsAndWineId",
                table: "ShoppingCartItems",
                newName: "IX_ShoppingCartItems_GetSpiritsAndWineSpiritsAndWineId");

            migrationBuilder.AddForeignKey(
                name: "FK_ShoppingCartItems_SpiritAndWines_GetSpiritsAndWineSpiritsAndWineId",
                table: "ShoppingCartItems",
                column: "GetSpiritsAndWineSpiritsAndWineId",
                principalTable: "SpiritAndWines",
                principalColumn: "SpiritsAndWineId",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
