﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using SpiritsAndLiquers.Data;

namespace SpiritsAndLiquers.Migrations
{
    [DbContext(typeof(AppDbContext))]
    [Migration("20170907103150_Orders")]
    partial class Orders
    {
        protected override void BuildTargetModel(ModelBuilder modelBuilder)
        {
            modelBuilder
                .HasAnnotation("ProductVersion", "1.1.2")
                .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            modelBuilder.Entity("SpiritsAndLiquers.Data.Models.Category", b =>
                {
                    b.Property<int>("CategoryId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("CategoryName");

                    b.Property<string>("Description");

                    b.HasKey("CategoryId");

                    b.ToTable("Categories");
                });

            modelBuilder.Entity("SpiritsAndLiquers.Data.Models.Order", b =>
                {
                    b.Property<int>("OrderId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("AdressLine1");

                    b.Property<string>("AdressLine2");

                    b.Property<string>("AdressLine3");

                    b.Property<string>("Country");

                    b.Property<string>("Email");

                    b.Property<string>("FirstName");

                    b.Property<string>("LastName");

                    b.Property<DateTime>("OrderPlaced");

                    b.Property<decimal>("OrderTotal");

                    b.Property<string>("PhoneNumber");

                    b.Property<string>("State");

                    b.Property<string>("ZipCode");

                    b.HasKey("OrderId");

                    b.ToTable("Orders");
                });

            modelBuilder.Entity("SpiritsAndLiquers.Data.Models.OrderDetail", b =>
                {
                    b.Property<int>("OrderDetailId")
                        .ValueGeneratedOnAdd();

                    b.Property<int>("Amount");

                    b.Property<int>("OrderId");

                    b.Property<decimal>("Price");

                    b.Property<int>("ProductId");

                    b.Property<int?>("SpiritsAndWineId");

                    b.HasKey("OrderDetailId");

                    b.HasIndex("OrderId");

                    b.HasIndex("SpiritsAndWineId");

                    b.ToTable("OrderDetails");
                });

            modelBuilder.Entity("SpiritsAndLiquers.Data.Models.ShoppingCartItem", b =>
                {
                    b.Property<int>("ShoppingCartItemId")
                        .ValueGeneratedOnAdd();

                    b.Property<int>("Amount");

                    b.Property<string>("ShoppingCartId");

                    b.Property<int?>("SpiritsAndWineId");

                    b.HasKey("ShoppingCartItemId");

                    b.HasIndex("SpiritsAndWineId");

                    b.ToTable("ShoppingCartItems");
                });

            modelBuilder.Entity("SpiritsAndLiquers.Data.Models.SpiritsAndWine", b =>
                {
                    b.Property<int>("SpiritsAndWineId")
                        .ValueGeneratedOnAdd();

                    b.Property<int>("CategoryId");

                    b.Property<string>("ImageThumbnailUrl");

                    b.Property<string>("ImageUrl");

                    b.Property<bool>("InStock");

                    b.Property<bool>("IsPreferred");

                    b.Property<string>("LongDescription");

                    b.Property<string>("Name");

                    b.Property<decimal>("Price");

                    b.Property<string>("ShortDescription");

                    b.HasKey("SpiritsAndWineId");

                    b.HasIndex("CategoryId");

                    b.ToTable("SpiritAndWines");
                });

            modelBuilder.Entity("SpiritsAndLiquers.Data.Models.OrderDetail", b =>
                {
                    b.HasOne("SpiritsAndLiquers.Data.Models.Order", "Order")
                        .WithMany("OrderLines")
                        .HasForeignKey("OrderId")
                        .OnDelete(DeleteBehavior.Cascade);

                    b.HasOne("SpiritsAndLiquers.Data.Models.SpiritsAndWine", "SpiritsAndWine")
                        .WithMany()
                        .HasForeignKey("SpiritsAndWineId");
                });

            modelBuilder.Entity("SpiritsAndLiquers.Data.Models.ShoppingCartItem", b =>
                {
                    b.HasOne("SpiritsAndLiquers.Data.Models.SpiritsAndWine", "SpiritsAndWine")
                        .WithMany()
                        .HasForeignKey("SpiritsAndWineId");
                });

            modelBuilder.Entity("SpiritsAndLiquers.Data.Models.SpiritsAndWine", b =>
                {
                    b.HasOne("SpiritsAndLiquers.Data.Models.Category", "Category")
                        .WithMany("SpiritsAndWines")
                        .HasForeignKey("CategoryId")
                        .OnDelete(DeleteBehavior.Cascade);
                });
        }
    }
}
