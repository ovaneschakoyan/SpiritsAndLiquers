﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using SpiritsAndLiquers.Data;

namespace SpiritsAndLiquers.Migrations
{
    [DbContext(typeof(AppDbContext))]
    [Migration("20170905162121_CartItem")]
    partial class CartItem
    {
        protected override void BuildTargetModel(ModelBuilder modelBuilder)
        {
            modelBuilder
                .HasAnnotation("ProductVersion", "1.1.2")
                .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            modelBuilder.Entity("SpiritsAndLiquers.Data.Models.Category", b =>
                {
                    b.Property<int>("CategoryId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("CategoryName");

                    b.Property<string>("Description");

                    b.HasKey("CategoryId");

                    b.ToTable("Categories");
                });

            modelBuilder.Entity("SpiritsAndLiquers.Data.Models.ShoppingCartItem", b =>
                {
                    b.Property<int>("ShoppingCartItemId")
                        .ValueGeneratedOnAdd();

                    b.Property<int>("Amount");

                    b.Property<int?>("GetSpiritsAndWineSpiritsAndWineId");

                    b.Property<string>("ShoppingCartId");

                    b.HasKey("ShoppingCartItemId");

                    b.HasIndex("GetSpiritsAndWineSpiritsAndWineId");

                    b.ToTable("ShoppingCartItems");
                });

            modelBuilder.Entity("SpiritsAndLiquers.Data.Models.SpiritsAndWine", b =>
                {
                    b.Property<int>("SpiritsAndWineId")
                        .ValueGeneratedOnAdd();

                    b.Property<int>("CategoryId");

                    b.Property<string>("ImageThumbnailUrl");

                    b.Property<string>("ImageUrl");

                    b.Property<bool>("InStock");

                    b.Property<bool>("IsPreferred");

                    b.Property<string>("LongDescription");

                    b.Property<string>("Name");

                    b.Property<decimal>("Price");

                    b.Property<string>("ShortDescription");

                    b.HasKey("SpiritsAndWineId");

                    b.HasIndex("CategoryId");

                    b.ToTable("SpiritAndWines");
                });

            modelBuilder.Entity("SpiritsAndLiquers.Data.Models.ShoppingCartItem", b =>
                {
                    b.HasOne("SpiritsAndLiquers.Data.Models.SpiritsAndWine", "GetSpiritsAndWine")
                        .WithMany()
                        .HasForeignKey("GetSpiritsAndWineSpiritsAndWineId");
                });

            modelBuilder.Entity("SpiritsAndLiquers.Data.Models.SpiritsAndWine", b =>
                {
                    b.HasOne("SpiritsAndLiquers.Data.Models.Category", "Category")
                        .WithMany("SpiritsAndWines")
                        .HasForeignKey("CategoryId")
                        .OnDelete(DeleteBehavior.Cascade);
                });
        }
    }
}
