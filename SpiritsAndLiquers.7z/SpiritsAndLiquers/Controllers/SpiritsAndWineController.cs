﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SpiritsAndLiquers.Data.interfaces;
using SpiritsAndLiquers.ViewModels;
using SpiritsAndLiquers.Data.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SpiritsAndLiquers.Controllers
{
    public class SpiritsAndWineController : Controller
    {
        private readonly ICategoryRepository _categoryRepository;
        private readonly ISpiritsAndWineRepository _spiritsAndWineRepository;

        public SpiritsAndWineController(ICategoryRepository categoryRepository, ISpiritsAndWineRepository spiritsAndWineRepository)
        {
            _categoryRepository = categoryRepository;
            _spiritsAndWineRepository = spiritsAndWineRepository;
        }

        public ViewResult List(string category)
        {
            string _category = category;
            IEnumerable<SpiritsAndWine> products;

            string currentCategory = string.Empty;

            if (string.IsNullOrEmpty(category))
            {
                products = _spiritsAndWineRepository.SpiritsAndWines.OrderBy(n => n.SpiritsAndWineId);
                currentCategory = "All products";
            }
            else
            {
                if (string.Equals("Red Wines", category, StringComparison.OrdinalIgnoreCase))
                {
                    products = _spiritsAndWineRepository.SpiritsAndWines.Where(p => p.Category.CategoryName.Equals("Red Wines")).OrderBy(p => p.Name);
                }
                else if (string.Equals("White Wines", category, StringComparison.OrdinalIgnoreCase))
                {
                    products = _spiritsAndWineRepository.SpiritsAndWines.Where(p => p.Category.CategoryName.Equals("White Wines")).OrderBy(p => p.Name);
                }
                else if (string.Equals("Dessert Wines", category, StringComparison.OrdinalIgnoreCase))
                {
                    products = _spiritsAndWineRepository.SpiritsAndWines.Where(p => p.Category.CategoryName.Equals("Dessert Wines")).OrderBy(p => p.Name);
                }
                else if (string.Equals("Vodka", category, StringComparison.OrdinalIgnoreCase))
                {
                    products = _spiritsAndWineRepository.SpiritsAndWines.Where(p => p.Category.CategoryName.Equals("Vodka")).OrderBy(p => p.Name);
                }
                else if (string.Equals("Rye Whiskey", category, StringComparison.OrdinalIgnoreCase))
                {
                    products = _spiritsAndWineRepository.SpiritsAndWines.Where(p => p.Category.CategoryName.Equals("Rye Whiskey")).OrderBy(p => p.Name);
                }
                else
                    products = _spiritsAndWineRepository.SpiritsAndWines.Where(p => p.Category.CategoryName.Equals("Bourbon")).OrderBy(p => p.Name);

                currentCategory = _category;
            }

            var spiritandwineListViewModel = new SpiritsAndWineListViewModel
            {
                SpiritsAndWines = products,
                CurrentCategory = currentCategory
            };

            return View(spiritandwineListViewModel);
        }
    }
}
  
