﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SpiritsAndLiquers.Data.interfaces;
using SpiritsAndLiquers.Data.Models;
using SpiritsAndLiquers.ViewModels;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SpiritsAndLiquers.Controllers
{
    public class ShoppingCartController : Controller
    {
        private readonly ISpiritsAndWineRepository _spiritsAndWineRepository;
        private readonly ShoppingCart _shoppingCart;

        public ShoppingCartController(ISpiritsAndWineRepository spiritsAndWineRepository,ShoppingCart shoppingCart)
        {
            _spiritsAndWineRepository = spiritsAndWineRepository;
            _shoppingCart = shoppingCart;
        }

        public ViewResult Index()
        {
            var items = _shoppingCart.GetShoppingCartItems();
            _shoppingCart.ShoppingCartItems = items;

            var sCVM = new ShoppingCartViewModel
            {
                ShoppingCart = _shoppingCart,
                ShoppingCartTotal = _shoppingCart.GetShoppingCartTotal()
            };

            return View(sCVM);
        }

        public RedirectToActionResult AddToShoppingCart(int spiritsandwineId)
        {
            var selectedSpiritsAndWine = _spiritsAndWineRepository.SpiritsAndWines.FirstOrDefault(p => p.SpiritsAndWineId == spiritsandwineId);
            if(selectedSpiritsAndWine!=null)
            {
                _shoppingCart.AddToCart(selectedSpiritsAndWine, 1);
            }
            return RedirectToAction("Index");
      }

        public RedirectToActionResult RemoveFromShoppingCart(int spiritsandwineId)
        {
            var selectedSpiritsAndWine = _spiritsAndWineRepository.SpiritsAndWines.FirstOrDefault(p => p.SpiritsAndWineId == spiritsandwineId);
            if(selectedSpiritsAndWine!=null)
            {
                _shoppingCart.RemoveFromCart(selectedSpiritsAndWine);
            }

            return RedirectToAction("Index");
        }
    }
}
