﻿using SpiritsAndLiquers.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpiritsAndLiquers.ViewModels
{
    public class HomeViewModel
    {
        public IEnumerable<SpiritsAndWine> PreferredSpiritsAndWine { get; set; }
    }
}
