﻿using SpiritsAndLiquers.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpiritsAndLiquers.ViewModels
{
    public class SpiritsAndWineListViewModel
    {
        public IEnumerable<SpiritsAndWine> SpiritsAndWines { get; set; }
        public string CurrentCategory { get; set; }
    }
}
